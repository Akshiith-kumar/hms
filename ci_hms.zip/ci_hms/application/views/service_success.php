<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span12">
			<div class="well alert-success">
				Service added successfully!
				<script type="text/javascript">
				setTimeout(function(){window.location.href="<?= base_url() ?><?=$type?>";}, 3000);
				</script>
			</div>
		</div>
	  </div>
	</div>
  </div>
</div>
