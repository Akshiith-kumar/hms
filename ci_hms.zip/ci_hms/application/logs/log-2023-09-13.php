<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\ci_hms\system\core\URI.php 102
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\ci_hms\system\core\Router.php 128
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$benchmark is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$hooks is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$config is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$log is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$utf8 is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$uri is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$exceptions is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$router is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$output is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$security is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$input is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$lang is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property Welcome::$db is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 397
ERROR - 2023-09-13 06:24:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\ci_hms\system\database\DB_driver.php 372
ERROR - 2023-09-13 06:24:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\xampp\htdocs\ci_hms\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-09-13 06:24:51 --> Unable to connect to the database
ERROR - 2023-09-13 06:24:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_hms\system\core\Exceptions.php:272) C:\xampp\htdocs\ci_hms\system\core\Common.php 571
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\ci_hms\system\core\URI.php 102
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\ci_hms\system\core\Router.php 128
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$benchmark is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$hooks is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$config is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$log is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$utf8 is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$uri is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$exceptions is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$router is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$output is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$security is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$input is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$lang is deprecated C:\xampp\htdocs\ci_hms\system\core\Controller.php 83
ERROR - 2023-09-13 06:44:57 --> Severity: 8192 --> Creation of dynamic property Welcome::$db is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 397
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\ci_hms\system\database\DB_driver.php 372
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 303
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 328
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 355
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 365
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 366
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 367
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 368
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 426
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 110
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\ci_hms\system\libraries\Session\Session.php 137
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$session is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 1284
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$user_l is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 1284
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$user_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$employee_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$room_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$departments_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$restaurant_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$medical_service_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$report_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$reservation_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$customer_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$sport_facility_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: 8192 --> Creation of dynamic property Welcome::$massage_room_m is deprecated C:\xampp\htdocs\ci_hms\system\core\Loader.php 359
ERROR - 2023-09-13 06:44:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_hms\system\core\Exceptions.php:272) C:\xampp\htdocs\ci_hms\system\helpers\url_helper.php 565
ERROR - 2023-09-13 06:54:45 --> Severity: Warning --> Undefined variable $next_week_freq C:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2023-09-13 06:54:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2023-09-13 06:54:45 --> Severity: Warning --> Undefined variable $next_week_freq C:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2023-09-13 06:54:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2023-09-13 06:54:52 --> Severity: Warning --> Undefined variable $next_week_freq C:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2023-09-13 06:54:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2023-09-13 06:54:52 --> Severity: Warning --> Undefined variable $next_week_freq C:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2023-09-13 06:54:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2023-09-13 06:55:56 --> Severity: Warning --> Undefined variable $customer_id C:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2023-09-13 06:56:12 --> Severity: Warning --> Undefined variable $next_week_freq C:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2023-09-13 06:56:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2023-09-13 06:56:12 --> Severity: Warning --> Undefined variable $next_week_freq C:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2023-09-13 06:56:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\ci_hms\application\views\footer.php 111
